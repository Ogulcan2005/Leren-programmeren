schoenen_lijst =[
    {
        "merk"  :  "Adidas",
        "model" :  "Superstar",
        "kleur" :  "rood",
        "prijs" :  99.95,
        "maten" : [37, 38, 39, 40, 41, 42, 43, 44, 45]
    },
    {
        "merk"  :  "Adidas",
        "model" :  "Superstar",
        "kleur" :  "blauw",
        "prijs" :  109.95,
        "maten" : [37, 38, 39, 40, 41, 42, 43, 44, 45, 46]
    },
    {
        "merk"  :  "Adidas",
        "model" :  "Superstar",
        "kleur" :  "groen",
        "prijs" :  84.95,
        "maten" : [37, 38, 39, 40, 41, 42, 43, 44, 45, 46]
    },
    {
        "merk"  :  "Nike",
        "model" :  "Air Max 270 kids",
        "kleur" :  "wit/ blauw",
        "prijs" :  69.95,
        "maten" : [33, 34, 35, 36, 37, 38, 39]
    },
    {
        "merk"  :  "Nike",
        "model" :  "Air 340 male",
        "kleur" :  "wit/ groen",
        "prijs" :  149.95,
        "maten" : [39, 40, 41, 42, 43, 44, 45, 46, 47, 48]
    },
    {
        "merk"  :  "Puma",
        "model" :  "Monarch field",
        "kleur" :  "zwart",
        "prijs" :  49.95,
        "maten" : [33, 34, 37, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48]
    },
    {
        "merk"  :  "Gaastra",
        "model" :  "Veelstedura",
        "kleur" :  "wit",
        "prijs" :  299.95,
        "maten" : [39, 40, 41, 42, 43, 44, 45, 46]
    },
    {
        "merk"  :  "Gaastra",
        "model" :  "Veelstedura kids",
        "kleur" :  "wit",
        "prijs" :  309.95,
        "maten" : [29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39]
    },

]

fonetische_kleuren = {
    "rood"  : "rode",
    "wit"   : "witte",
    "blauw" : "blauwe",
    "wit/ blauw" : "combi wit/ blauwe"
}