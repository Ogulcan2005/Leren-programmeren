from schoenen_data import *

# opdracht 1:
# Print alle schoenen van het merk Adidas


# filteren
# opdracht 2:
# Vraag een merk en print vervolgens alle modellen van het merk en de bijbehorende prijs.


# opdracht 3:
# Vraag een merk en print vervolgens alle witte schoenen mits duurder dan €100.


# opdracht 4:
# vraag de maat van de klant en print vervolgens:
# "fonetische_kleuren Merknaam Modelnaam, prijs"
# uiteraard alleen de schoenen die beschikbaar zijn in betreffende maat.


# Opdracht 5 (medium):
# print van de duurste schoen: merk en model en doe dat ook voor de goedkoopste.


# opdracht 6 (hard):
# print van de schoen leverbaar in de grootste maat :
# IN maat ... leverbaar: merk. model en kleur van de schoenen
# (let op, filter in: in code)